ace.define("ace/snippets/abap",[], function(require, exports, module) {
"use strict";

exports.snippetText = "";
exports.scope = "abap";

});
                (function() {
                    ace.require(["ace/snippets/abap"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            